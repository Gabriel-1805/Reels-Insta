# regla.md — Serie "Así funciona"

Especificación viva para producir episodios de divulgación en formato vertical, renderizados con HyperFrames.
Los patrones salen de un análisis de un video de referencia. **Todo el contenido (guion, textos, gráficos) es original.**

Versión: **v0.6** · Fases 1, 2, 3 y 4 y el cierre común validados; reutilización de `comun/` validada en el Episodio 2; 3D real validado en preview y en render · Los valores `TBD` se completan al verificarlos.

Historial: v0.1 análisis inicial · v0.2 tokens del logo, flujo Codespaces+Actions · v0.3 cámara virtual, subtítulos sin choque, recuadros por frase, `comun/`, reglas del lint · v0.4 perspectiva 3D, profundidad, etiquetas que se dibujan, escenario con celular que escanea, zoom a la pantalla, banco de pruebas · v0.4.1 cierre fijo común con perfil de la cuenta y hoja de compartir · v0.5 sonido: solo voz y efectos (sin música), whooshes graves, sonidos del QR electrónicos, mezcla automática · v0.5.1 Episodio 2: flujo «audio primero», revisión de Whisper, personajes y animales, sala en un portal, muestras reales para sonidos orgánicos · **v0.6 Fase 4: 3D real con three.js (plantilla en `comun/plantillas/`), reglas de línea de tiempo y de render.**

---

## 0. Principios

1. Hacer visible lo invisible: bajar de escala (objeto → capa → detalle).
2. La imagen explica, la voz guía, el subtítulo marca el ritmo.
3. Un concepto nuevo por tramo.
4. El final pide una acción concreta sobre una persona concreta.
5. Se copian **patrones**, nunca elementos del video de referencia.
6. Lo aprendido vive en archivos (`regla.md`, `comun/`), no en la memoria del chat.
7. **Coherencia física:** lo que se muestra debe poder ocurrir (p. ej. la cámara trasera del celular apunta al objeto; el espectador ve la pantalla, no la parte trasera).

---

## 1. Formato técnico

| Parámetro | Valor |
|---|---|
| Resolución | 1080 × 1920 (9:16) |
| FPS | 30 |
| Duración | 45–75 s (máx. 90 s) |
| Codec | H.264, 8–12 Mbps, AAC |
| Motor | HyperFrames (HTML + CSS + GSAP seekable → MP4) |

---

## 2. Tokens de marca (medidos en el logo)

| Token | Hex | Uso |
|---|---|---|
| `--navy` | `#192653` | Paneles, tarjetas |
| `--bg` | `#0B0F24` | Fondo general y módulos oscuros |
| `--blue` | `#4B5BFF` | Recuadros de palabra clave, nodos, bordes |
| `--amber` | `#FFB703` | Energía, datos, etiquetas |
| `--dim` | `#8A93B8` | Subtítulo inactivo |
| `--bad` | `#FF5A5F` | Errores y estados «no funciona» (✕) |

Tipografía: sans geométrica (Montserrat con fallback), pesos 400/600/800.
Fondo: radial oscuro + rejilla de plano técnico + partículas flotantes lentas.

---

## 3. Cámara virtual (Fase 1)

Todo el contenido vive dentro de un «mundo» (`#world`) y se anima la cámara, no los objetos.

- `focus(px,py,S)` lleva un punto del mundo al centro con zoom `S`.
- `cam(inicio,duración,estado,ease)` mueve mundo, rejilla y polvo con **paralaje** (rejilla 25 %, polvo 50 %, con tope de desplazamiento).
- `blur()` añade un pulso de desenfoque en los movimientos rápidos.
- Escalera de zoom: objeto completo → capa interna → detalle (2,2–2,3×).
- Transiciones por **movimiento continuo**, no por corte: pull-back, empuje, giro y **zoom-through** (destino ≈ 64×).
- Ritmo ráfaga → pausa: movimiento de ~1,2–1,4 s y luego deriva lenta (`ease:'none'`) mientras habla la voz.
- Todo se sitúa con **fracciones de escena** `T(i,f)` y **tiempos de cláusula** `C(k,f)`, nunca con segundos fijos.

---

## 4. Perspectiva y profundidad (Fase 2)

- `tilt(inicio,dur,{rx,ry,rz})` inclina el mundo en 3D (perspectiva 1400, rx ≈ 34–36°) y enciende la **niebla de profundidad** (`#fog`): lo lejano se funde con el fondo.
- **Úsalo en planos amplios.** En primeros planos desplaza el encuadre (la rotación no es sobre el punto enfocado).
- `enganchar(inicio,{rx,ry,rz})`: llega torcido y se endereza con rebote suave; sirve para el momento «se detecta / se fija».
- **Brillo:** copia desenfocada debajo (`feGaussianBlur` de SVG). No usar `drop-shadow` sobre el propio elemento.
- **Etiquetas que se dibujan:** la línea guía se traza (`scaleY`), aparece el nodo y luego el texto en una píldora con fondo.
- **El mundo tiene lugar, no solo objeto:** superficie en perspectiva (mesa), soporte, sombra, partículas y elementos que explican (celular, haz, bits).
- **Celular que escanea:** pantalla al frente (visor con esquinas de enfoque), haz desde el borde superior, bits que viajan del objeto al celular. Zoom a la pantalla cuando la voz explica el resultado.
- Metáfora de datos: bloques de respaldo que llegan a reconstruir una zona tapada.
- Receta por receta y su código: `comun/patrones.md`.

---

## 4b. 3D real (Fase 4, validada)

- **Validado:** la escena 3D se mueve en el **preview** de HyperFrames y sale en el **render de GitHub Actions** (WebGL disponible allí).
- **Plantilla:** `comun/plantillas/escena3d.html` → `episodios/epNN/escena.capa3d.html` (sustituir `__T0__` y `__DUR__`). `construir.py` la coloca detrás del mundo 2D, las etiquetas y los subtítulos.
- **Contrato con HyperFrames:** three.js 0.181.2 desde jsdelivr; escena creada de forma síncrona; `setSize(W,H,false)` y `setPixelRatio(1)`; **sin `requestAnimationFrame`**; dibujar solo en el evento `hf-seek` con el tiempo local (`global − T0`); **todo procedural y con semilla** (sin modelos ni texturas remotas).
- **La línea de tiempo GSAP raíz debe durar TODA la composición.** Si solo dura lo que dura la última animación, el 3D se congela justo ahí (le pasó a la prueba: se quedó quieto en el segundo 1). `camara.js` ya lo garantiza en los episodios.
- **Preview ≠ render.** Que el preview funcione no basta: renderizar siempre en Actions y mirar el MP4.
- **Comprobar que Actions renderiza el episodio correcto** (el campo del episodio vuelve al valor por defecto en cada ejecución).
- **Coste:** ≈ 1–2 s por fotograma en software (medido en local) → **usar 3D en pocas escenas**; un episodio entero en 3D tardaría demasiado.
- **Cámara 3D propia**, independiente de la cámara virtual CSS. La franja de subtítulos queda libre con `setViewOffset` y una máscara en el canvas.
- Para que una escena 3D ocupe toda la pantalla, ocultar lo 2D (mundo) en ese tramo; para un fondo 3D, dejar el mundo con transparencia.
- Cada escena 3D necesita sus `sfx(...)` en `escena.js` (el 3D no registra sonidos solo).

---

## 5. Subtítulos (Fase 1)

- **Franja superior reservada** (y ≈ 130–420). El contenido visual se desvanece con una máscara (`mask-image`) antes de llegar ahí: **nada pasa por detrás del texto.**
- Karaoke: palabra activa blanca en negrita, resto `--dim`. Grupos de ≤ 3 palabras, sin cruzar el final de una cláusula.
- **Recuadros azules con nodos:** una palabra clave por cláusula como mínimo (máx. 2): 1) lista fija (`palabras_clave.txt` del episodio + la común); 2) si no hay, la palabra de contenido más larga (≥ 5 letras, no conector); 3) cláusulas solo de conectores no llevan recuadro.
- Etiquetas inferiores con **fondo propio**. Zona inferior (25 %) libre para la interfaz de la plataforma.
- Tiempos: el inicio de cada cláusula es **medido** en las pausas del audio; el de cada palabra, **estimado por sílabas**.

---

## 5.1 Cierre fijo (común a todos los videos, validado)

- **Todos los episodios terminan con la misma frase:** «Sígueme y envíaselo a ese amigo que…» (se completa con el tema del episodio).
- **Registro de voz: tuteo** («Sígueme», «envíaselo»). Los subtítulos deben coincidir con lo que se escucha, aunque quien guiona use voseo.
- La escena vive en `comun/cierre.*` y se dispara con las **palabras reales de la voz**:
  - «Sígueme» → aparece el perfil de la cuenta (logo, usuario) y el botón Seguir pasa a Siguiendo.
  - «envíaselo» → se toca el icono de compartir y sube la hoja de compartir.
  - «amigo» → se elige un contacto; después Enviar → «✓ Enviado».
- **Avatares de la hoja:** ilustraciones originales, **alternando chico y chica** (Mati, Sofi, Nacho, Vale). Sin caras ni nombres de terceros.
- **Interfaz propia:** marco de celular e iconos dibujados por nosotros; no se reproduce el logo ni la interfaz de Instagram.
- Cuenta: `comun/marca.json` (usuario) y `comun/marca/logo-avatar.png` (logo sobre `--bg`). Título bajo el perfil: `cierre.json` de cada episodio.
- Si la voz va muy rápida, el cierre espera a que cada paso se vea (perfil ≥ 1,3 s antes de la hoja). **Al grabar, dejar una pausa de ≥ 0,5 s antes de «Sígueme» y frases cortas.**
- Cuenta del proyecto: **asifunciona.reel**.

---

## 6. Ritmo y guion

- Gancho en los primeros 3 s con una pregunta o paradoja visual.
- Plantilla: gancho · respuesta · mecanismo (3 zooms) · casos límite · resultado · dato · cierre · CTA.
- Palabras por minuto: el Ep. 1 salió a ~177 ppm (rápido). **Meta: 130–160 ppm; CTA ≤ 10 palabras con pausa previa ≥ 0,5 s.**
- `guion.md` por episodio (tiempo · narración · escena y edición · función · ppm).
- Un solo registro de voz (tú o vos). Cifras técnicas con fuente verificada antes de publicar.

---

## 7. Audio y sonido (Fase 3, validada)

**Decisión del proyecto: solo voz y efectos, sin música de fondo.**

- Voz limpia y sin música. Objetivo **−14 LUFS**, pico **≤ −1,5 dBTP** (con voz muy comprimida, −14,7 LUFS es aceptable).
- Voz: propia, o TTS gratuito local (**Kokoro**, voz `em_alex`).
- Todo el sonido se mezcla fuera del navegador en un solo `audio.wav` (voz + efectos). `index.html` usa `audio.wav` si existe, si no `voz.wav`. **Subir `audio.wav` al repo** para que Actions lo use.
- **Los efectos salen de la línea de tiempo:** `sfx(t,'nombre',vol,dur)`; `cam()`, `tilt()`, `etiquetas()` y el cierre registran los suyos. Así el sonido sigue a la imagen y a las palabras de la voz, no a segundos fijos.
- **Efectos originales sintetizados con numpy** (`comun/sonido/efectos.py`): sin muestras de terceros, sin problemas de licencia.
- **Whooshes graves y suaves:** centro ≈ 150–430 Hz, ataque lento, cuerpo en graves; nunca agudos (el barrido del zoom-through debe ser el más grave, no el más brillante).
- **Sonidos del QR/tecnología electrónicos:** onda cuadrada + reducción de resolución (clics de etiquetas, lock de esquinas, haz de escaneo, bits, confirmaciones). Los físicos (rayón, mancha, golpes) siguen siendo orgánicos.
- Niveles respecto a la voz en `GANANCIA` (dB); los efectos bajan 3 dB mientras habla la voz.
- **Máximo ~6 señales por segundo** (el informe de `mezclar.py` lo avisa). Los grupos largos (muchos «pop» o «tick» seguidos) se aclaran: uno de cada dos o tres.
- Comando: `python3 comun/sonido/hacer_sonido.py episodios/epNN` (una vez antes: `npm install --no-save gsap jsdom`).
- **Sin música es una decisión, no una carencia:** si algún día se añade, debe quedar ≈ 14 dB bajo la voz y bajar 8 dB más mientras se habla.
- La prueba mide niveles y tiempos, **no oye**: escuchar siempre el preview.

---

## 8. Estructura del repo

```
Reels-Insta/
├── regla.md
├── .github/workflows/render.yml
├── comun/   tokens.css camara.js subtitulos.js etiquetas.js palabras.py palabras_clave.txt
│            cierre.html cierre.css cierre.js marca.json marca/logo-avatar.png
│            sonido.js sonido/{efectos.py,mezclar.py,extraer.js,hacer_sonido.py,efectos/*.wav}
│            alinear.py construir.py probar.js README.md patrones.md
└── episodios/epNN-tema/
    ├── guion.txt guion.md voz.wav tiempos.json palabras_clave.txt cierre.json
    ├── audio.wav cues.json     # GENERADOS por hacer_sonido.py (voz + efectos)
    ├── escena.css escena.mundo.html escena.clips.html escena.js   # lo propio del tema
    └── index.html            # GENERADO por construir.py (no se edita a mano)
```

---

## 8b. Lecciones del Episodio 2 (flujo «audio primero»)

- **Orden:** 1) se genera el audio aparte → 2) se analiza (duración, pausas, volumen, tono) → 3) se transcribe y **se revisa a mano** → 4) se escribe `guion.txt` → 5) `alinear.py` → 6) se diseñan las escenas → 7) `construir.py` → 8) `hacer_sonido.py`.
- **Whisper se equivoca en los bordes de cada tramo.** Casos reales: «Sígueme» partido en «Sí» + «gueme» (inventó un «Sí.»), «Mígueme», y «por qué ocurre» cortado al final de la ventana. **Antes de dar por buena una frase, volver a transcribir con una ventana más larga** y confirmar con el autor las palabras dudosas. Nunca añadir palabras que no se oyen.
- **`comun/` se reutilizó sin tocar** la cámara, los subtítulos, las etiquetas y el cierre. Solo hizo falta generalizar el identificador de la composición (ahora es el nombre de la carpeta del episodio) y añadir efectos nuevos.
- **Personajes y animales** (HTML/CSS originales): no inclinar en 3D (deforma); cuello y hombros en una sola pieza (escote + cuello trapezoidal + sombra); anillos de onda con `immediateRender:false` para que no se vean antes de tiempo.
- **Mundo ancho + pan:** objetos repartidos a lo largo del mundo y cámara que se desplaza entre ellos; si dos palabras se dicen con < 1 s de diferencia, encuadrar ambas en un solo plano.
- **Escena dentro de una escena:** un portal (div con `overflow:hidden`) al que entra la cámara con zoom + desenfoque y del que sale con otro movimiento; dentro, figuras pequeñas con cejas, pupilas y signos «?».
- **Sonidos orgánicos (voz humana, bostezos): la síntesis no convenció (sonaba a whoosh).** Usar **grabaciones propias** en `comun/sonido/muestras/<nombre>.wav` (recortadas, con ruido reducido) y tomar la duración de la animación de la propia muestra (`DUR_BOST`). La síntesis sirve para sonidos electrónicos y de movimiento, no para voces.
- **Un chico y una chica:** cada personaje usa su propio sonido (`bostezo_m`, `bostezo_f`).

---

## 9. Flujo de un episodio

1. Copiar `ep01-qr` a `epNN-tema` como base.
2. `guion.txt` (un párrafo por línea) + `voz.wav`.
3. `python3 comun/alinear.py episodios/epNN-tema`
4. Editar `escena.*` y `palabras_clave.txt` (recetas en `comun/patrones.md`).
5. `python3 comun/construir.py episodios/epNN-tema`
5b. `python3 comun/sonido/hacer_sonido.py episodios/epNN-tema` (añade `sfx(...)` a `escena.js` para lo propio del tema)
6. `node comun/probar.js episodios/epNN-tema/index.html` (0 solapes, determinista)
7. `npx hyperframes lint` → `preview` → commit/push.
8. Actions → `render-video` → descargar el MP4.

Git: `git add` desde la raíz; subir `voz.wav`; no subir `voces/`, `tmp/`, `*.mp4`, `.hyperframes/`.
**Entrega por zip:** subir el zip a la raíz del repo por la web, `git pull`, `python3 -m zipfile -e archivo.zip .`, `git rm -q archivo.zip`, reconstruir.

---

## 10. Reglas aprendidas del lint y de la animación

- No animar `autoAlpha`/`opacity`/`visibility` en elementos con clase `clip`: anima un hijo.
- No animar `left`/`top`/`width`/`height`: usar `x`, `y`, `scale`.
- Todo `<audio>` y elemento de la línea de tiempo lleva `id` (sin `id`, el audio sale mudo).
- Posiciones absolutas en la línea de tiempo; nunca encadenar `.to()` sin posición (se añade al final).
- No solapar dos animaciones de la misma propiedad sobre el mismo elemento.
- No poner `transform` en el CSS de un elemento que GSAP anime desde cero: usar `fromTo`.
- Las advertencias `nested_structure_needs_subcomposition` no bloquean el render (pendiente).
- Preview con video viejo: borrar `episodios/epNN/.hyperframes` (caché) y reabrir.
- La simulación (`probar.js`) no ve imágenes: **siempre mirar el preview** antes de dar algo por bueno.
- La línea de tiempo GSAP raíz debe cubrir toda la duración de la composición (ver 4b).

---

## 11. Métricas por episodio

| Métrica | Dónde leerla | Meta |
|---|---|---|
| Retención a 3 s / media | Gráfico de retención | `TBD` |
| Finalización | % que llega al final | `TBD` |
| Compartidos / guardados / comentarios | Interacciones | `TBD` |

---

## 12. Checklist de producción

- [ ] Guion en tabla, ppm en rango, CTA corto, un solo registro de voz
- [ ] Gancho de 3 s con pregunta o paradoja
- [ ] El guion termina con «Sígueme y envíaselo a ese amigo que…» y hay pausa antes de «Sígueme»
- [ ] Voz limpia, ≈ −14 LUFS, pico ≤ −1,5 dBTP
- [ ] Sonido: ≤ 6 señales por segundo, whooshes graves, sonidos del QR/tecnología electrónicos, escuchado en el preview
- [ ] `alinear.py` con ≥ 90 % de cláusulas ancladas
- [ ] Una palabra clave con recuadro por cláusula
- [ ] Nada entra en la franja de subtítulos
- [ ] La escena es físicamente coherente (qué cara se ve, hacia dónde apunta)
- [ ] `probar.js` sin solapes · `lint` sin errores · preview revisado
- [ ] Cifras con fuente verificada · render con Actions · métricas registradas

---

## 13. Hoja de ruta

| Fase | Contenido | Estado |
|---|---|---|
| 1 | Cámara virtual, transiciones, subtítulos sincronizados, `comun/` | ✅ Validada (Ep. 1) |
| 2 | Perspectiva 3D, profundidad, etiquetas que se dibujan, escenario con celular, zoom a la pantalla | ✅ Validada (Ep. 1) |
| 3 | Efectos de sonido (sin música): whooshes graves, sonidos electrónicos, mezcla automática | ✅ Validada (Ep. 1) |
| — | Episodio 2: reutilización de `comun/` (flujo «audio primero») | ✅ Validado |
| 4 | 3D real con three.js | ✅ Validada (prueba en preview y render) |

---

## 14. Pendientes

- [ ] Integrar la **primera escena 3D real** en un episodio (elegir 1–2 escenas por episodio)
- [ ] Anotar cuánto tarda el render de Actions con 3D (por segundo de video)
- [ ] Decidir si los personajes 2D estilo «formas redondeadas» (idea aparcada) se hacen antes del Ep. 3
- [ ] Registrar las métricas del Ep. 2 y compararlas con las del Ep. 1
- [ ] Probar el tercer episodio con un tema distinto para confirmar el flujo «audio primero»
- [ ] Revisar con otros episodios que el cierre se ve bien en el preview (zona inferior de la plataforma)
- [ ] Adaptar el TTS (Kokoro) para leer `guion.txt` y generar `voz.wav` dentro de `comun/`
- [ ] Resolver las advertencias de subcomposición del lint
- [ ] Verificar los porcentajes de corrección de errores (L 7 / M 15 / Q 25 / H 30 %) en ISO/IEC 18004
- [ ] Mejorar la sincronía palabra a palabra (alineación forzada)
- [ ] Registrar las métricas del Ep. 1
