# Guion · Ep. 02 — Por qué el bostezo se contagia

Audio generado aparte (`voz.wav`): 51,9 s · 161 palabras · ~187 ppm de media · voz masculina grave (F0 ≈ 131 Hz).
Original: −15,9 LUFS y pico 0,0 dBFS. Mezcla final (voz + efectos, sin música): ≈ −15,3 LUFS, pico −1,5 dBTP (el pico del original limita subir más).
Tiempos medidos sobre las pausas reales del audio (15 de 17 finales de cláusula coinciden con una pausa).

| Tiempo | Narración | Escena y edición | Función | ppm |
|---|---|---|---|---|
| 00:00–00:11 | Y si te dijera que puedes empezar a bostezar solo por ver este vídeo, alguien bosteza delante de ti y de repente sientes unas ganas enormes de hacerlo también. Pero ¿qué está pasando dentro de tu cerebro? | Primer plano de la boca de una persona que bosteza; plano general con «alguien» y «tú»; la onda del bostezo viaja y «tú» también bosteza | Gancho y ancla | 198 |
| 00:11–00:18 | Cuando ves a otra persona bostezar, tu cerebro procesa ese gesto y puede desencadenar una respuesta similar en ti. | La cámara entra en la cabeza de «tú»: la piel se vuelve transparente, el cerebro procesa el gesto y los nodos se iluminan | Mecanismo 1: el cerebro | 193 |
| 00:18–00:23 | Es lo que conocemos como bostezo contagioso. Y lo más curioso es que no necesitas estar cansado. | Plano general; etiqueta «Bostezo contagioso»; los dos bostezan; batería llena: no hace falta estar cansado | Mecanismo 2: contagioso | 206 |
| 00:23–00:30 | Basta con ver o incluso escuchar un bostezo para que aparezcan las ganas de hacerlo. Los científicos todavía investigan por qué. | Perspectiva 3D; iconos de ver y escuchar; la onda llega a «tú»; lupa con «?»: se sigue investigando | Mecanismo 3: ver o escuchar | 181 |
| 00:30–00:37 | Los mecanismos de imitación y los procesos relacionados con la percepción social podrían influir, pero aún no existe una explicación definitiva. | Red entre las dos personas con puntos que van y vienen: imitación y percepción social; «?» grande: sin explicación definitiva | Casos límite: ¿por qué? | 181 |
| 00:37–00:44 | Y esto no sucede solamente entre humanos. También se ha observado en animales como los chimpancés y los perros. | Pan hacia el chimpancé y el perro: también bostezan y se contagian | Animales | 202 |
| 00:44–00:47 | Ahora que has llegado hasta aquí, dime, ¿te han dado ganas de bostezar? | Plano de grupo con cadena de ondas; empuje a «tú» y zoom-through dentro de su boca abierta | Pregunta al espectador | 238 |
| 00:47–00:53 | Sígueme y envíaselo a ese amigo que se contagia de cada bostezo que ve. | Cierre fijo de `comun/`: perfil, hoja de compartir y «Enviado» | CTA | 215 |

Notas:
- El texto se tomó del audio con Whisper y se revisó a mano: «Sígueme» (Whisper escribió «Mígueme») y el final «…de cada bostezo que ve».
- El primer análisis añadió un «Sí.» que no existe: Whisper cortó «Sígueme» al borde de un tramo. Ya corregido.
- Ritmo rápido (~187 ppm frente a la meta de 130–160). Decisión del autor: mantenerlo.
- El cierre fijo arranca en 47,8 s (pausa de 0,5 s antes de «Sígueme»).
- «Los mecanismos de imitación… podrían influir»: la ciencia no tiene una explicación definitiva; el video lo dice y el guion no debe afirmar más.
- Personajes y animales: ilustraciones originales dibujadas con HTML/CSS.
